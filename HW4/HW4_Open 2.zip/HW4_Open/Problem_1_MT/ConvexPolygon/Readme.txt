^^^ How to use this program ^^^
1. Press the 'a' key to start a polygon creation.
2. Click the right button to add a vertex.
3. Press the 'f' key to finish the polygon creation.
4. Press the 's' key to save the polygon into the file named 'polygon.txt'.
* If your polygon is not convex, you need to repeat the creation process.