        for(int i=0;i<=cnt;i++){
            for(int j=0;j<=cnt;j++){
                cout<<S[i][j]<<" ";
            }
            cout<<"\n";
        }